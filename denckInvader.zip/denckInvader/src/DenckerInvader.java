import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JComponent;
import javax.swing.JFrame;

public class DenckerInvader extends JComponent implements Runnable {

	int x = 0, y = 0, numOfImg = 100;

	Image thinkingEmoji, laughingCryingEmoji, oneHundredEmoji, okEmoji, clappingEmoji, boiEmoji;

	public DenckerInvader() {

		thinkingEmoji = Toolkit.getDefaultToolkit().getImage("download.png");
		laughingCryingEmoji = Toolkit.getDefaultToolkit().getImage("Crying-Emoji-PNG-Transparent-Image.png");
		oneHundredEmoji = Toolkit.getDefaultToolkit().getImage("100_Emoji.png");
		okEmoji = Toolkit.getDefaultToolkit().getImage("ok-hand-sign_1f44c.png");
		clappingEmoji = Toolkit.getDefaultToolkit().getImage("clapping-hands-sign_1f44f.png");
		boiEmoji = Toolkit.getDefaultToolkit().getImage("e0908c50-fd8d-0132-451f-0a2ca390b447.png");

		Thread t = new Thread(this);
		t.start();
	}

	public void update(Graphics g) {
		
		paint(g);
	}

	public void paint(Graphics g) {
		for (int i = 0; i < numOfImg; i++) {
			g.drawImage(thinkingEmoji, x, y, 100, 100, this);
			g.drawImage(laughingCryingEmoji, x, y, 100, 100, this);
			g.drawImage(oneHundredEmoji, x, y, 100, 100, this);
			g.drawImage(okEmoji, x, y, 100, 100, this);
			g.drawImage(clappingEmoji, x, y, 100, 100, this);
			g.drawImage(boiEmoji, x, y, 100, 100, this);
		}
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("Dencker is better than EVERYTHING!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);
		frame.setVisible(true);
		frame.add(new DenckerInvader());
		frame.getContentPane().setBackground(Color.black);
	}

	@Override
	public void run() {
		while (true) {

			repaint();
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}